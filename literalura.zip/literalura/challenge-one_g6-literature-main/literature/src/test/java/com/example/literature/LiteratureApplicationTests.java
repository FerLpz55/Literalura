package com.example.literature;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiteratureApplicationTests {

	@Test
	void contextLoads() {
	}

}
